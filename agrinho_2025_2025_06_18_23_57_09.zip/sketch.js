let cena = 0; // 0: Tela de Título, 1: Campo, 2: Cidade, 3: Transição Festa, 4: Diálogo, 5: Seleção Dificuldade, 6: Minigame 1, 7: Minigame 1 Concluído, 8: Minigame 2, 9: Finalização

// Variáveis para movimentação dos personagens
let joaoX = -150; // Começa fora da tela para João
let anaX = 1050;  // Começa fora da tela para Ana
const VELOCIDADE_PERSONAGEM = 2; // Velocidade de movimento dos personagens

let dialogoIndex = 0;
let tempoCena = 0;
let fadingAlpha = 0; // Para transições de fade

let nivelDificuldade = 'facil'; // Padrão
let pontuacao = 0;
let produtosEntregues1 = 0; // Contador para o Minigame 1
let produtosEntregues2 = 0; // Contador para o Minigame 2
let produtosNoNivel = []; // Lista de produtos para o nível atual do Minigame 1
let produtosEntrega = []; // Lista de produtos para o Minigame 2
let casasAlvo = []; // Lista de casas para o Minigame 2

// Diálogos expandidos
let dialogos = [
  "João: O sol nasce no campo, e com ele a esperança de uma nova colheita.",
  "João: Nossa terra é generosa, e daqui vêm os alimentos que nutrem a todos.",
  "João: Imagino a cidade, com suas ruas movimentadas e gente de todo tipo.",
  "João: Como será que nossos produtos chegam até lá, transformando o dia das pessoas?",
  "Ana: Na cidade, o ritmo é outro, mas a energia é contagiante.",
  "Ana: Recebemos produtos de todos os cantos, organizamos e distribuímos.",
  "Ana: É um desafio levar tudo fresquinho para a mesa de cada família.",
  "Ana: Mas como seria mostrar a eles de onde tudo vem, essa conexão mágica?",
  "João: Ei, Ana! Que bom te encontrar por aqui na festa!",
  "Ana: João! Que surpresa! Pensei a mesma coisa... nossa, o campo e a cidade juntos!",
  "João: Pois é! Já pensou se mostrássemos como trabalhamos, juntos, numa feira?",
  "Ana: Uau, que ideia incrível! Vamos montar uma barraca aqui, agora mesmo!",
  "João: Assim, todos veem como o campo produz e a cidade distribui, como nos completamos.",
  "Ana: Perfeito! Mãos à obra para organizar essa feira na festa!"
];

// Minigame 1 - Definição completa de todos os produtos e barracas possíveis
const TODOS_PRODUTOS_FEIRA = [
  { nome: "Milho", cor: "yellow", tipo: "Hortifruti" },
  { nome: "Leite", cor: "white", tipo: "Laticínios" },
  { nome: "Tomate", cor: "red", tipo: "Hortifruti" },
  { nome: "Ovos", cor: "beige", tipo: "Laticínios" },
  { nome: "Maçãs", cor: [255, 50, 50], tipo: "Hortifruti" },
  { nome: "Pão", cor: [200, 150, 100], tipo: "Padaria" },
  { nome: "Queijo", cor: [255, 255, 0], tipo: "Laticínios" },
  { nome: "Cenoura", cor: [255, 140, 0], tipo: "Hortifruti" },
  { nome: "Bolo", cor: [240, 240, 240], tipo: "Padaria" },
  { nome: "Cebola", cor: [150, 100, 50], tipo: "Hortifruti" },
  { nome: "Iogurte", cor: [200, 200, 255], tipo: "Laticínios" }
];

const TODAS_BARRACAS = [
  { nome: "Hortifruti", tipo: "Hortifruti", x: 200, y: 150, recebidos: [] },
  { nome: "Laticínios", tipo: "Laticínios", x: 450, y: 150, recebidos: [] },
  { nome: "Padaria", tipo: "Padaria", x: 700, y: 150, recebidos: [] }
];

// Minigame 2 - Produtos para entrega e Tipos de Casas
const TODOS_PRODUTOS_ENTREGA = [
    { nome: "Cesta de Legumes", cor: [100, 200, 100], tipo: "Vegana" },
    { nome: "Kit Laticínios", cor: [150, 200, 255], tipo: "Família com Bebê" },
    { nome: "Pães Frescos", cor: [180, 130, 80], tipo: "Café da Manhã" },
    { nome: "Frutas Variadas", cor: [255, 180, 0], tipo: "Saudável" },
    { nome: "Comida Pronta", cor: [255, 100, 100], tipo: "Apressada" },
    { nome: "Bolo Especial", cor: [255, 200, 200], tipo: "Celebrar" }
];

const TODAS_CASAS_ALVO = [
    { nome: "Casa Vegana", tipo: "Vegana", x: 150, y: 180, recebidos: [] },
    { nome: "Casa Família c/ Bebê", tipo: "Família com Bebê", x: 350, y: 180, recebidos: [] },
    { nome: "Casa Café da Manhã", tipo: "Café da Manhã", x: 550, y: 180, recebidos: [] },
    { nome: "Casa Saudável", tipo: "Saudável", x: 750, y: 180, recebidos: [] },
    { nome: "Casa Apressada", tipo: "Apressada", x: 250, y: 350, recebidos: [] },
    { nome: "Casa Celebrar", tipo: "Celebrar", x: 650, y: 350, recebidos: [] }
];

let produtoSelecionado = null; // Produto que está sendo arrastado

// Cores e constantes para facilitar a leitura
const COR_CAMPO = [34, 139, 34];
const COR_CIDADE = [200];
const COR_FESTA_CHAO = [255, 228, 196];
const COR_Ceu = [135, 206, 235];
const PERSONAGEM_LARGURA = 40;
const PERSONAGEM_ALTURA = 60;
const SOLO_ALTURA = 100;

function setup() {
  createCanvas(900, 500);
  textFont('Georgia');
}

function draw() {
  background(COR_Ceu); // Céu como fundo padrão

  // Lógica principal de cenas
  switch (cena) {
    case 0:
      mostrarTelaTitulo();
      break;
    case 1:
      mostrarCampo();
      moverJoao();
      break;
    case 2:
      mostrarCidade();
      moverAna();
      break;
    case 3:
      mostrarFestaAmbiente(); // Apenas o ambiente da festa
      moverParaCentro();
      break;
    case 4:
      mostrarFestaAmbiente();
      mostrarPersonagens();
      mostrarDialogo();
      break;
    case 5:
      mostrarSelecaoDificuldade();
      break;
    case 6:
      mostrarMinigame1(); // Primeiro Minigame (Feira)
      break;
    case 7:
        mostrarTransicaoMinigame2(); // Transição entre os minigames
        break;
    case 8:
        mostrarMinigame2(); // Segundo Minigame (Entrega)
        break;
    case 9:
      mostrarFinalizacao();
      break;
  }

  // Efeito de fade (para transições suaves)
  if (fadingAlpha > 0) {
    fill(0, fadingAlpha);
    rect(0, 0, width, height);
    fadingAlpha -= 5; // Velocidade do fade out
  }
}

// --- Funções de Ajuda para Desenho ---
function desenharPersonagem(x, y, corCorpo, corCabeca) {
  fill(corCorpo);
  ellipse(x, y, PERSONAGEM_LARGURA, PERSONAGEM_ALTURA); // Corpo
  fill(corCabeca);
  ellipse(x, y - PERSONAGEM_ALTURA / 2, PERSONAGEM_LARGURA * 0.75, PERSONAGEM_LARGURA * 0.75); // Cabeça
}

function desenharFogueira(x, y) {
  fill(139, 69, 19); // Lenha
  rect(x - 15, y - 10, 30, 20);
  fill(255, random(100, 200), 0, 200); // Fogo
  ellipse(x, y - 30, 30 + random(5), 40 + random(5));
}

function desenharPredio(x, y, h) {
  fill(COR_CIDADE[0] - 20);
  rect(x, y - h, 60, h);
  fill(255, 255, 0); // Janelas
  rect(x + 10, y - h + 20, 15, 15);
  rect(x + 35, y - h + 20, 15, 15);
  rect(x + 10, y - h + 50, 15, 15);
  rect(x + 35, y - h + 50, 15, 15);
}

// --- Cena 0: Tela de Título ---
function mostrarTelaTitulo() {
  background(COR_Ceu);
  fill(0, 100, 0);
  rect(0, height - SOLO_ALTURA, width, SOLO_ALTURA); // Chão verde

  textAlign(CENTER);
  fill(255);
  textSize(48);
  text("Campo e Cidade: Uma História de Conexão", width / 2, height / 2 - 50);
  textSize(24);
  text("Clique para começar a jornada!", width / 2, height / 2 + 20);
  textSize(16);
  text("Desenvolvido por [Seu Nome]", width / 2, height - 30); // Adicione seu nome aqui
}

// --- Cena 1: Campo ---
function mostrarCampo() {
  fill(COR_CAMPO[0], COR_CAMPO[1], COR_CAMPO[2]);
  rect(0, height - SOLO_ALTURA, width, SOLO_ALTURA); // Chão verde do campo

  // Adicionar elementos do campo
  fill(139, 69, 19); // Tronco
  rect(50, height - SOLO_ALTURA - 50, 20, 50);
  fill(0, 150, 0); // Folhas
  ellipse(60, height - SOLO_ALTURA - 70, 80, 80);

  fill(100, 50, 0); // Cerca
  for (let i = 100; i < width - 100; i += 30) {
    rect(i, height - SOLO_ALTURA - 40, 5, 40);
    rect(i, height - SOLO_ALTURA - 20, 30, 5);
  }

  textSize(26);
  fill(0);
  textAlign(CENTER);
  text("João, no campo, cultiva os alimentos com dedicação...", width / 2, 40);

  // Trator do João
  fill(200, 50, 50); // Corpo do trator
  rect(joaoX, height - SOLO_ALTURA - 20, 80, 20);
  rect(joaoX + 20, height - SOLO_ALTURA - 40, 30, 20);
  fill(0); // Rodas
  ellipse(joaoX + 15, height - SOLO_ALTURA, 30, 30);
  ellipse(joaoX + 65, height - SOLO_ALTURA, 30, 30);
  
  // João no trator
  fill(255, 0, 0); // Cor da roupa de João
  ellipse(joaoX + 45, height - SOLO_ALTURA - 50, PERSONAGEM_LARGURA * 0.8, PERSONAGEM_ALTURA * 0.8); // Corpo
  fill(255, 220, 180); // Cor da pele de João
  ellipse(joaoX + 45, height - SOLO_ALTURA - 75, PERSONAGEM_LARGURA * 0.6, PERSONAGEM_LARGURA * 0.6); // Cabeça
}

function moverJoao() {
  joaoX += VELOCIDADE_PERSONAGEM; // Velocidade do trator
  if (joaoX > width + 100) { // Saiu da tela
    cena = 2;
    tempoCena = 0;
    fadingAlpha = 255; // Inicia fade out para próxima cena
  }
}

// --- Cena 2: Cidade ---
function mostrarCidade() {
  fill(COR_CIDADE[0]);
  rect(0, height - SOLO_ALTURA, width, SOLO_ALTURA); // Chão da cidade

  // Prédios da cidade (agora imóveis)
  for (let i = 0; i < width; i += 120) {
    desenharPredio(i, height - SOLO_ALTURA, 200 - (i % 50) * 0.5); // Alturas variadas mas fixas
  }

  textSize(26);
  fill(0);
  textAlign(CENTER);
  text("Ana, na cidade, organiza a distribuição dos produtos...", width / 2, 40);

  // Carro de entregas da Ana
  fill(0, 100, 255); // Cor do carro
  rect(anaX, height - SOLO_ALTURA - 30, 80, 30);
  rect(anaX + 10, height - SOLO_ALTURA - 50, 60, 20); // Cabine
  fill(0); // Rodas
  ellipse(anaX + 20, height - SOLO_ALTURA, 25, 25);
  ellipse(anaX + 60, height - SOLO_ALTURA, 25, 25);

  // Ana no carro
  fill(0, 100, 255); // Cor da roupa da Ana
  ellipse(anaX + 40, height - SOLO_ALTURA - 60, PERSONAGEM_LARGURA * 0.8, PERSONAGEM_ALTURA * 0.8);
  fill(255, 220, 200); // Cor da pele da Ana
  ellipse(anaX + 40, height - SOLO_ALTURA - 85, PERSONAGEM_LARGURA * 0.6, PERSONAGEM_LARGURA * 0.6);
}

function moverAna() {
  anaX -= VELOCIDADE_PERSONAGEM; // Velocidade do carro
  if (anaX < -100) { // Saiu da tela
    cena = 3;
    tempoCena = 0;
    joaoX = -150; // Reseta posição inicial para cena 3
    anaX = width + 150; // Reseta posição inicial para cena 3
    fadingAlpha = 255; // Inicia fade out para próxima cena
  }
}

// --- Cena 3: Chegada na Festa (com mais elementos) ---
function moverParaCentro() {
  mostrarFestaAmbiente(); // Desenha só o ambiente da festa

  // Elementos adicionais da festa
  fill(139, 69, 19); // Barracas vazias
  rect(100, height - SOLO_ALTURA - 50, 80, 50, 5);
  rect(width - 180, height - SOLO_ALTURA - 50, 80, 50, 5);
  fill(200, 150, 0); // Teto das barracas
  triangle(100, height - SOLO_ALTURA - 50, 140, height - SOLO_ALTURA - 90, 180, height - SOLO_ALTURA - 50);
  triangle(width - 180, height - SOLO_ALTURA - 50, width - 140, height - SOLO_ALTURA - 90, width - 100, height - SOLO_ALTURA - 50);

  // Árvores de festa junina
  fill(139, 69, 19);
  rect(width / 2 - 200, height - SOLO_ALTURA - 80, 20, 80);
  rect(width / 2 + 200, height - SOLO_ALTURA - 80, 20, 80);
  fill(0, 100, 0);
  ellipse(width / 2 - 190, height - SOLO_ALTURA - 100, 70, 70);
  ellipse(width / 2 + 210, height - SOLO_ALTURA - 100, 70, 70);


  const POS_JOAO_ALVO = width / 2 - 100;
  const POS_ANA_ALVO = width / 2 + 100;

  // Movimento de João
  if (joaoX < POS_JOAO_ALVO) {
    joaoX += VELOCIDADE_PERSONAGEM;
  } else {
    joaoX = POS_JOAO_ALVO; // Garante que pare no lugar exato
  }
  // Movimento de Ana
  if (anaX > POS_ANA_ALVO) {
    anaX -= VELOCIDADE_PERSONAGEM;
  } else {
    anaX = POS_ANA_ALVO; // Garante que pare no lugar exato
  }

  // Desenha João
  desenharPersonagem(joaoX, height - SOLO_ALTURA / 2, [255, 0, 0], [255, 220, 180]);
  // Desenha Ana
  desenharPersonagem(anaX, height - SOLO_ALTURA / 2, [0, 100, 255], [255, 220, 200]);

  // Se ambos pararam, avança a cena após um pequeno atraso
  if (joaoX === POS_JOAO_ALVO && anaX === POS_ANA_ALVO) {
    tempoCena++;
    if (tempoCena > 90) { // Tempo para eles se "olharem" antes do diálogo
      cena = 4;
      fadingAlpha = 0; // Garante que o fade não atrapalhe o diálogo
    }
  }
}

// --- Cena 4: Diálogo na Festa ---
function mostrarFestaAmbiente() {
  fill(COR_FESTA_CHAO[0], COR_FESTA_CHAO[1], COR_FESTA_CHAO[2]);
  rect(0, height - SOLO_ALTURA, width, SOLO_ALTURA); // Chão da festa

  textSize(26);
  fill(0);
  textAlign(CENTER);
  text("Na festa junina, campo e cidade se encontram!", width / 2, 40);

  // Bandeirinhas (estáticas e 2 cores)
  for (let i = 0; i < width + 40; i += 40) {
    if (i % 80 === 0) fill(255, 0, 0); // Vermelho
    else fill(255, 255, 0); // Amarelo
    triangle(i, 100, i + 20, 80, i + 40, 100);
  }

  // Fogueira no centro
  desenharFogueira(width / 2, height - SOLO_ALTURA);
}

function mostrarPersonagens() {
  // Posições fixas para o diálogo
  desenharPersonagem(width / 2 - 100, height - SOLO_ALTURA / 2, [255, 0, 0], [255, 220, 180]); // João
  desenharPersonagem(width / 2 + 100, height - SOLO_ALTURA / 2, [0, 100, 255], [255, 220, 200]); // Ana
}

function mostrarDialogo() {
  fill(255, 255, 255, 220); // Balão de fala semitransparente
  stroke(0);
  rect(100, 120, 700, 80, 15); // Balão maior e arredondado
  noStroke();
  fill(0);
  textSize(20);
  textAlign(CENTER);
  text(dialogos[dialogoIndex], width / 2, 155);
  
  // Indicador para o próximo diálogo
  textSize(14);
  fill(100);
  text("Clique para continuar...", width / 2, 185);
}

function mousePressed() {
  if (cena === 0) { // Da tela de título para a cena do campo
    cena = 1;
    fadingAlpha = 255; // Começa um fade para a cena 1
    return;
  }

  if (cena === 4) { // Lógica de avançar diálogo
    dialogoIndex++;
    if (dialogoIndex >= dialogos.length) {
      cena = 5; // Vai para a seleção de dificuldade
      fadingAlpha = 255; // Inicia fade out
    }
    return;
  }

  if (cena === 5) { // Lógica de seleção de dificuldade
    if (mouseY > height / 2 - 40 && mouseY < height / 2 + 40) {
      if (mouseX > width / 2 - 200 - 50 && mouseX < width / 2 - 200 + 50) { // Fácil
        nivelDificuldade = 'facil';
        cena = 6;
        fadingAlpha = 255;
        resetMinigame1();
      } else if (mouseX > width / 2 - 50 && mouseX < width / 2 + 50) { // Médio
        nivelDificuldade = 'medio';
        cena = 6;
        fadingAlpha = 255;
        resetMinigame1();
      } else if (mouseX > width / 2 + 100 - 50 && mouseX < width / 2 + 100 + 50) { // Difícil
        nivelDificuldade = 'dificil';
        cena = 6;
        fadingAlpha = 255;
        resetMinigame1();
      }
    }
    return;
  }

  // Ativar arraste no Minigame 1
  if (cena === 6) {
    for (let produto of produtosNoNivel) {
      if (dist(mouseX, mouseY, produto.x, produto.y) < 30) {
        produtoSelecionado = produto;
        produto.arrastando = true;
        break;
      }
    }
    return;
  }

  // Ativar arraste no Minigame 2
  if (cena === 8) {
    for (let produto of produtosEntrega) {
      if (dist(mouseX, mouseY, produto.x, produto.y) < 30) {
        produtoSelecionado = produto;
        produto.arrastando = true;
        break;
      }
    }
    return;
  }
}

function mouseDragged() {
  if (cena === 6 && produtoSelecionado) {
    produtoSelecionado.x = mouseX;
    produtoSelecionado.y = mouseY;
  } else if (cena === 8 && produtoSelecionado) {
    produtoSelecionado.x = mouseX;
    produtoSelecionado.y = mouseY;
  }
}

function mouseReleased() {
  // Lógica do Minigame 1
  if (cena === 6 && produtoSelecionado) {
    let entregueCorretamente = false;
    for (let b of TODAS_BARRACAS) {
      if (dist(produtoSelecionado.x, produtoSelecionado.y, b.x, b.y) < 60 && produtoSelecionado.tipo === b.tipo) {
        b.recebidos.push(produtoSelecionado.nome);
        produtoSelecionado.x = -1000; // Remove da tela
        produtoSelecionado.y = -1000;
        pontuacao += 10;
        produtosEntregues1++;
        entregueCorretamente = true;
        break;
      }
    }
    
    if (!entregueCorretamente) {
      produtoSelecionado.x = produtoSelecionado.originalX;
      produtoSelecionado.y = produtoSelecionado.originalY;
    }

    produtoSelecionado.arrastando = false;
    produtoSelecionado = null;

    if (produtosEntregues1 >= produtosNoNivel.length) {
      cena = 7; // Vai para a transição para o Minigame 2
      fadingAlpha = 255;
      tempoCena = 0; // Resetar tempo para a transição
    }
    return;
  }

  // Lógica do Minigame 2
  if (cena === 8 && produtoSelecionado) {
    let entregueCorretamente = false;
    for (let casa of TODAS_CASAS_ALVO) {
      if (dist(produtoSelecionado.x, produtoSelecionado.y, casa.x, casa.y) < 70 && produtoSelecionado.tipo === casa.tipo) {
        casa.recebidos.push(produtoSelecionado.nome);
        produtoSelecionado.x = -1000; // Remove da tela
        produtoSelecionado.y = -1000;
        pontuacao += 20; // Mais pontos por ser a entrega final
        produtosEntregues2++;
        entregueCorretamente = true;
        break;
      }
    }
    
    if (!entregueCorretamente) {
      produtoSelecionado.x = produtoSelecionado.originalX;
      produtoSelecionado.y = produtoSelecionado.originalY;
    }

    produtoSelecionado.arrastando = false;
    produtoSelecionado = null;

    if (produtosEntregues2 >= produtosEntrega.length) {
      cena = 9; // Vai para a finalização
      fadingAlpha = 255;
    }
    return;
  }
}

// --- Cena 5: Seleção de Dificuldade ---
function mostrarSelecaoDificuldade() {
  background(245, 230, 200);
  textAlign(CENTER);
  fill(0);
  textSize(32);
  text("Escolha o Nível de Dificuldade", width / 2, height / 2 - 100);

  // Botões de dificuldade
  let btnWidth = 100;
  let btnHeight = 80;
  let btnY = height / 2;

  // Fácil
  fill(100, 200, 100);
  rect(width / 2 - 200, btnY - btnHeight / 2, btnWidth, btnHeight, 10);
  fill(0);
  textSize(24);
  text("Fácil", width / 2 - 150, btnY + 10);

  // Médio
  fill(200, 200, 100);
  rect(width / 2 - 50, btnY - btnHeight / 2, btnWidth, btnHeight, 10);
  fill(0);
  textSize(24);
  text("Médio", width / 2, btnY + 10);

  // Difícil
  fill(200, 100, 100);
  rect(width / 2 + 100, btnY - btnHeight / 2, btnWidth, btnHeight, 10);
  fill(0);
  textSize(24);
  text("Difícil", width / 2 + 150, btnY + 10);
}

// --- Cena 6: Minigame 1 (Feira) ---
function resetMinigame1() {
  produtosNoNivel = [];
  produtosEntregues1 = 0;
  pontuacao = 0; // Zera a pontuação para começar o minigame

  for (let b of TODAS_BARRACAS) {
    b.recebidos = [];
  }

  let numProdutos = 0;
  let produtosDisponiveisParaNivel = [];

  if (nivelDificuldade === 'facil') {
    numProdutos = 4;
    produtosDisponiveisParaNivel = [
      TODOS_PRODUTOS_FEIRA[0], TODOS_PRODUTOS_FEIRA[1], TODOS_PRODUTOS_FEIRA[2], TODOS_PRODUTOS_FEIRA[5]
    ];
  } else if (nivelDificuldade === 'medio') {
    numProdutos = 7;
    produtosDisponiveisParaNivel = [
      TODOS_PRODUTOS_FEIRA[0], TODOS_PRODUTOS_FEIRA[1], TODOS_PRODUTOS_FEIRA[2], TODOS_PRODUTOS_FEIRA[3],
      TODOS_PRODUTOS_FEIRA[4], TODOS_PRODUTOS_FEIRA[5], TODOS_PRODUTOS_FEIRA[6]
    ];
  } else if (nivelDificuldade === 'dificil') {
    numProdutos = TODOS_PRODUTOS_FEIRA.length;
    produtosDisponiveisParaNivel = TODOS_PRODUTOS_FEIRA;
  }

  shuffle(produtosDisponiveisParaNivel, true);
  for (let i = 0; i < numProdutos; i++) {
    let p = produtosDisponiveisParaNivel[i];
    let posX = 100 + (i * (width - 200) / (numProdutos - 1 || 1));
    if (numProdutos === 1) posX = width / 2;

    produtosNoNivel.push({
      nome: p.nome, x: posX, y: 420, arrastando: false, cor: p.cor,
      originalX: posX, originalY: 420, tipo: p.tipo
    });
  }
}

function mostrarMinigame1() {
  background(245, 230, 200);
  textAlign(CENTER);
  textSize(24);
  fill(0);
  text("Feira da Conexão: Arraste os produtos para a barraca correta!", width / 2, 40);

  textSize(20);
  fill(50, 150, 50);
  text("Pontos: " + pontuacao, width - 120, 40);
  text("Nível: " + nivelDificuldade.toUpperCase(), 120, 40);

  for (let p of produtosNoNivel) {
    if (p.x > 0) {
      fill(p.cor);
      ellipse(p.x, p.y, 50, 50);
      fill(0);
      textSize(16);
      text(p.nome, p.x, p.y - 35);
    }
  }

  for (let b of TODAS_BARRACAS) {
    fill(180, 120, 70);
    rect(b.x - 50, b.y, 100, 80, 10);
    fill(255, 100, 100);
    triangle(b.x - 60, b.y, b.x, b.y - 50, b.x + 60, b.y);

    fill(0);
    textSize(16);
    text(b.nome, b.x, b.y + 100);
    
    for (let i = 0; i < b.recebidos.length; i++) {
      fill(50, 50, 50);
      textSize(12);
      text(b.recebidos[i], b.x, b.y + 120 + i * 15);
    }
  }
}

// --- Cena 7: Transição Minigame 2 ---
function mostrarTransicaoMinigame2() {
    background(50, 150, 100); // Fundo verde para transição
    fill(255);
    textAlign(CENTER);
    textSize(36);
    text("Feira concluída! Agora, vamos entregar na cidade!", width / 2, height / 2 - 20);
    textSize(20);
    text("Clique para começar as entregas...", width / 2, height / 2 + 30);

    // Pequeno delay antes de poder clicar para a próxima cena
    tempoCena++;
    if (tempoCena > 90 && mouseIsPressed) { // Permitir clique após 1.5s
        cena = 8;
        fadingAlpha = 255;
        resetMinigame2();
    }
}


// --- Cena 8: Minigame 2 (Entrega na Cidade) ---
function resetMinigame2() {
    produtosEntrega = [];
    produtosEntregues2 = 0;

    // Reinicia as casas (limpando produtos recebidos)
    for (let casa of TODAS_CASAS_ALVO) {
        casa.recebidos = [];
    }

    // Seleciona e posiciona os produtos de entrega
    let numProdutosEntrega = TODOS_PRODUTOS_ENTREGA.length;
    let produtosDisponiveisEntrega = TODOS_PRODUTOS_ENTREGA;
    shuffle(produtosDisponiveisEntrega, true);

    for (let i = 0; i < numProdutosEntrega; i++) {
        let p = produtosDisponiveisEntrega[i];
        let posX = 100 + (i * (width - 200) / (numProdutosEntrega - 1 || 1)); // Distribui no fundo da tela
        produtosEntrega.push({
            nome: p.nome, x: posX, y: 420, arrastando: false, cor: p.cor,
            originalX: posX, originalY: 420, tipo: p.tipo
        });
    }
}

function mostrarMinigame2() {
    background(COR_CIDADE[0]); // Fundo de cidade para o minigame 2
    textAlign(CENTER);
    textSize(24);
    fill(0);
    text("Entrega na Cidade: Leve os produtos para as casas certas!", width / 2, 40);

    textSize(20);
    fill(50, 150, 50);
    text("Pontos: " + pontuacao, width - 120, 40);

    // Desenha as casas alvo
    for (let casa of TODAS_CASAS_ALVO) {
        fill(220, 180, 150); // Cor da casa
        rect(casa.x - 40, casa.y, 80, 80, 10);
        fill(150, 80, 0); // Porta
        rect(casa.x - 15, casa.y + 40, 30, 40);
        fill(100, 100, 255); // Janela
        rect(casa.x - 30, casa.y + 10, 20, 20);
        rect(casa.x + 10, casa.y + 10, 20, 20);

        fill(0);
        textSize(14);
        text(casa.nome, casa.x, casa.y + 100); // Nome da casa

        // Ícone ou texto indicando o que a casa precisa
        fill(50, 50, 50);
        textSize(12);
        text("Precisa: " + casa.tipo, casa.x, casa.y + 120);

        // Produtos recebidos na casa
        for (let i = 0; i < casa.recebidos.length; i++) {
            fill(0, 150, 0); // Verde para indicar produto entregue
            text("✔️ " + casa.recebidos[i], casa.x, casa.y + 140 + i * 15);
        }
    }

    // Desenha os produtos para entrega
    for (let p of produtosEntrega) {
        if (p.x > 0) { // Só desenha se não foi entregue
            fill(p.cor);
            rect(p.x - 20, p.y - 20, 40, 40, 5); // Produtos como caixas
            fill(0);
            textSize(14);
            text(p.nome, p.x, p.y - 30);
        }
    }
}

// --- Cena 9: Finalização ---
function mostrarFinalizacao() {
  background(50, 150, 100); // Cor de fundo mais celebratória
  fill(255);
  textAlign(CENTER);
  textSize(36);
  text("Jornada Completa: Campo e Cidade Conectados!", width / 2, height / 2 - 60);
  textSize(24);
  text("Você ajudou a unir o campo, a feira e as casas da cidade!", width / 2, height / 2 - 10);
  text("Sua pontuação final: " + pontuacao + " pontos!", width / 2, height / 2 + 30);
  textSize(20);
  text("Essa união fortalece nosso futuro. 🌽🏙️✨", width / 2, height / 2 + 80);
}
